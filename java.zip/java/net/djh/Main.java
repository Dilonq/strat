package net.djh;

import net.djh.globe.GlobeRenderer;
import net.djh.globe.InputController;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.system.MemoryUtil.NULL;

public class Main {
    private long window;
    private final int width = 1200;
    private final int height = 900;
    private InputController input;
    private GlobeRenderer renderer;

    public void run() {
        init();
        loop();
        glfwDestroyWindow(window);
        glfwTerminate();
    }

    private void init() {
        glfwInit();
        window = glfwCreateWindow(width, height, "Globe", NULL, NULL);
        glfwMakeContextCurrent(window);
        glfwSwapInterval(1);
        glfwShowWindow(window);
        GL.createCapabilities();

        renderer = new GlobeRenderer(width, height);
        input = new InputController(width, height, window, renderer);
    }

    private void loop() {
        double lastTime = glfwGetTime();
        int frames = 0;

        while (!glfwWindowShouldClose(window)) {
            //render
            renderer.render(input);


            //fps monitor
            frames++;
            double currentTime = glfwGetTime();
            if (currentTime - lastTime >= 1.0) {
//                System.out.println("FPS: " + frames);
                frames = 0;
                lastTime = currentTime;
            }

            //vsync shit
            glfwSwapBuffers(window);
            glfwPollEvents();
        }
    }

    public static void main(String[] args) {
        new Main().run();
    }
}