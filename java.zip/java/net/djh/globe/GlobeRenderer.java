package net.djh.globe;

import org.joml.*;
import org.lwjgl.BufferUtils;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.lang.Math;
import java.nio.*;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.stb.STBImage.*;

public class GlobeRenderer {
    public Texture texture;
    public Texture heightMap;
    public final int width;
    public final int height;

    public GlobeRenderer(int width, int height) {
        this.width = width;
        this.height = height;
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_COLOR_MATERIAL);
        glEnable(GL_TEXTURE_2D);
        glClearColor(0f, 0f, 0f, 1f);
        texture = new Texture("src/main/resources/textures/hemi.jpg");
        heightMap = new Texture("src/main/resources/textures/heightmap.png");
    }

    public void render(InputController input) {
        Matrix4f viewMatrix = input.getViewMatrix();

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();

        //fov stuff
        float near = 0.01f;
        float far = 100.0f;
        float fovY = (float) Math.toRadians(45.0);
        float aspect = (float) width / height;
        float top = (float) (Math.tan(fovY / 2.0) * near);
        float bottom = -top;
        float right = top * aspect;
        float left = -right;
        glFrustum(left, right, bottom, top, near, far);


        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        FloatBuffer fb = BufferUtils.createFloatBuffer(16);
        glLoadMatrixf(new Matrix4f()
                .mul(viewMatrix)                                // camera orbit
//                .rotateY((float) Math.toRadians(180))           // position on europe/africa
                .get(BufferUtils.createFloatBuffer(16)));


        glBindTexture(GL_TEXTURE_2D, texture.id);
        renderSphere(1.5f, 64, 64,heightMap,0.15f); // globe is centered at origin


        //debug click dot
        Vector3f gp = input.getGrabPoint();
        if (gp != null) renderDot(gp);

        renderDot(new Vector3f(0f, 1.5f, 0f));
        renderDot(new Vector3f(1.5f, 0f, 0f));

    }


    private void renderDot(Vector3f coordinates) {
        glDisable(GL_TEXTURE_2D);
        glColor3f(1f, 1f, 1f); // red

        glPointSize(8f);
        glBegin(GL_POINTS);
        glVertex3f(coordinates.x, coordinates.y, coordinates.z);
        glEnd();

        glColor3f(1f, 1f, 1f); // reset to white
        glEnable(GL_TEXTURE_2D);
    }



    private void renderSphere(float radius, int lats, int longs) {
        for (int i = 0; i <= lats; i++) {
            double theta0 = Math.PI * i / lats;
            double theta1 = Math.PI * (i + 1) / lats;

            double y0 = -Math.cos(theta0);
            double y1 = -Math.cos(theta1);

            double r0 = Math.sin(theta0);
            double r1 = Math.sin(theta1);

            glBegin(GL_QUAD_STRIP);
            for (int j = 0; j <= longs; j++) {
                double phi = -2 * Math.PI * j / longs + Math.PI;

                double x = Math.cos(phi);
                double z = Math.sin(phi);

                double u = (double) j / longs;
                double v0 = (double) i / lats;
                double v1 = (double) (i + 1) / lats;

                // First vertex
                glTexCoord2d(u, v0);
                glVertex3d(x * r0 * radius, y0 * radius, z * r0 * radius);

                // Second vertex
                glTexCoord2d(u, v1);
                glVertex3d(x * r1 * radius, y1 * radius, z * r1 * radius);
            }
            glEnd();
        }
    }

    public void renderSphere(float radius, int lats, int longs, Texture heightmap, float heightScale) {
        for (int i = 0; i <= lats; i++) {
            double theta0 = Math.PI * i / lats;
            double theta1 = Math.PI * (i + 1) / lats;

            double y0 = -Math.cos(theta0);
            double y1 = -Math.cos(theta1);

            double baseR0 = Math.sin(theta0);
            double baseR1 = Math.sin(theta1);

            glBegin(GL_QUAD_STRIP);
            for (int j = 0; j <= longs; j++) {
                double phi = 2 * Math.PI * j / longs;
                double x = Math.cos(phi);
                double z = Math.sin(phi);

                float h0 = getHeightFromTexture(heightmap, theta0 - Math.PI / 2, phi);
                float h1 = getHeightFromTexture(heightmap, theta1 - Math.PI / 2, phi);

                double r0 = radius * (1.0 + h0 * heightScale);
                double r1 = radius * (1.0 + h1 * heightScale);

                float u = 1.0f - (float)(((phi + Math.PI) % (2 * Math.PI)) / (2 * Math.PI));

                float v0 = (float) (theta0 / Math.PI);
                float v1 = (float) (theta1 / Math.PI);

                glTexCoord2f(u, v0);
                glNormal3d(x * baseR0, y0, z * baseR0);
                glVertex3d(r0 * x * baseR0, r0 * y0, r0 * z * baseR0);

                glTexCoord2f(u, v1);
                glNormal3d(x * baseR1, y1, z * baseR1);
                glVertex3d(r1 * x * baseR1, r1 * y1, r1 * z * baseR1);
            }
            glEnd();
        }
    }


    //helpers

    private float getHeightFromTexture(Texture heightmap, double latitude, double longitude) {
        if (heightmap == null || heightmap.buffer == null) return 0f;

        // ✅ Shift longitude by π so it matches texture u-coord
        longitude = (longitude + Math.PI) % (2 * Math.PI);

        int x = (int)((longitude) / (2 * Math.PI) * heightmap.width);
        int y = (int)((Math.PI / 2 - latitude) / Math.PI * heightmap.height);

        x = Math.min(Math.max(0, x), heightmap.width - 1);
        y = Math.min(Math.max(0, y), heightmap.height - 1);

        Color rgba = texture.getColorFromPosition(new Vector2i(x,y));
        int grayscale = rgba.grayscale();

        return grayscale / 255f;
    }

    public Vector2i getPositionFromRaycast(Vector3f hit) {
        hit.normalize(); // sphere radius = 1

        float lat = (float) Math.toDegrees(Math.asin(hit.y));
        float lon = (float) Math.toDegrees(Math.atan2(hit.z, hit.x)) - 90f;

        float u = 1f - (((lon + 360f) % 360f) / 360f);
        float v = (lat + 90f) / 180f;

        int px = Math.min(texture.width - 1, Math.max(0, (int) (u * texture.width)));
        int py = Math.min(texture.height - 1, Math.max(0, (int) (v * texture.height)));

        return new Vector2i(px,py);
    }

    public static Vector2f getCoordinatesFromRaycast(Vector3f hit) {
        hit.normalize(); // sphere radius = 1

        float lat = (float) Math.toDegrees(Math.asin(hit.y));
        float lon = (float) Math.toDegrees(Math.atan2(hit.z, hit.x)) - 90f;

        return new Vector2f(lat,lon);
    }

    public Matrix4f getProjectionMatrix() {
        return new Matrix4f().frustum(-1f, 1f, -0.75f, 0.75f, 1f, 100f);
    }

    public Matrix4f getViewMatrix(float zoom, Quaternionf rotation) {
        return new Matrix4f().translate(0f, 0f, zoom).rotate(rotation);
    }
}