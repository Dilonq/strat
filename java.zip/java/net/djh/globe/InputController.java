package net.djh.globe;

import org.joml.*;

import java.lang.Math;

import static org.lwjgl.glfw.GLFW.*;

public class InputController {
    private final int width, height;
    private final long window;
    private final GlobeRenderer renderer;
    private final Quaternionf rotation = new Quaternionf();
    private Quaternionf targetRotation = new Quaternionf();

    private Vector3f grabPoint = null;
    private Vector2f mouse = new Vector2f();
    private Vector2f lastMouse = new Vector2f();
    private boolean dragging = false;

    //camera vars
    private float yaw = 8.00505f;
    private float pitch = 0.814763f;

    private float targetYaw = yaw;
    private float targetPitch = pitch;

    private float distance = 2.4394112f;
    private float targetDistance = distance;



    public InputController(int width, int height, long window, GlobeRenderer renderer) {
        this.width = width;
        this.height = height;
        this.window = window;
        this.renderer = renderer;
        installCallbacks();
    }

    public float getDistance() {
        distance += (targetDistance - distance) * 0.02f;
        return distance;
    }

    private void installCallbacks() {
        glfwSetScrollCallback(window, (w, xo, yo) -> {
            float zoomSpeed = 0.1f; // tweak this

            targetDistance *= Math.exp(-yo * zoomSpeed);

            float minDist = 1.6f;
            float maxDist = 50f;
            targetDistance = Math.max(minDist, Math.min(maxDist, targetDistance));
        });





        glfwSetKeyCallback(window, (w, key, scancode, action, mods) -> {
            if (action != GLFW_PRESS && action != GLFW_REPEAT) return;

            float step = 0.01f;

            switch (key) {
                case GLFW_KEY_LEFT  -> targetYaw -= step;
                case GLFW_KEY_RIGHT -> targetYaw += step;
                case GLFW_KEY_UP    -> targetPitch += step;
                case GLFW_KEY_DOWN  -> targetPitch -= step;
                case GLFW_KEY_R -> {
                    targetYaw = yaw = 0f;
                    targetPitch = pitch = 0f;
                    targetDistance = distance = 6f;
                }
            }

            // Clamp pitch
            float limit = (float) Math.toRadians(89);
            targetPitch = Math.max(-limit, Math.min(limit, targetPitch));
        });


        glfwSetMouseButtonCallback(window, (w, button, action, mods) -> {
            //middle click drag
            if (button == GLFW_MOUSE_BUTTON_MIDDLE) {
                //usual
                dragging = (action == GLFW_PRESS);
                if (!dragging) grabPoint = null;
            }

            //leftclick
            if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
                double[] x = new double[1];
                double[] y = new double[1];
                glfwGetCursorPos(window, x, y);

                Vector3f origin = getCameraPosition();
                Vector3f ray = screenToRay((float) x[0], (float) y[0]);
                Vector3f hit = intersectRayWithSphere(origin, ray, 1.5f);

                if (hit != null) {
//                    printColorAt(renderer.texture,hit);
//                    System.out.println(distance+" yaw"+yaw+" p"+pitch);
                }
            }
        });


        glfwSetCursorPosCallback(window, (w, xpos, ypos) -> {
            mouse.x = (float) xpos;
            mouse.y = (float) ypos;

            if (!dragging) return;

            Vector3f origin = getCameraPosition();
            Vector3f ray = screenToRay(xpos, ypos);
            Vector3f newHit = intersectRayWithSphere(origin, ray, 1.5f);

            if (newHit == null) return;
            newHit.normalize();

            if (grabPoint == null) {
                grabPoint = new Vector3f(newHit);
                return; // wait for next frame
            }


            //axis and pitchyaw stuff wtv


            Vector3f axis = new Vector3f(newHit).cross(grabPoint).normalize();
            float angle = newHit.angle(grabPoint);

            if (Float.isNaN(angle) || angle < 0.0001f || axis.lengthSquared() < 0.00001f || !axis.isFinite()) return;

            angle = Math.min(angle, 0.5f); // avoid large angle jitter

            Quaternionf delta = new Quaternionf().rotateAxis(angle, axis);
            Vector3f dir = getCameraDirection();
            delta.transform(dir);
            updateYawPitchFromDirection(dir);
        });



    }

    public void printColorAt(Texture texture, Vector3f hit) {
        Vector2f coords = renderer.getCoordinatesFromRaycast(hit);
        Vector2i position = renderer.getPositionFromRaycast(hit);
        renderer.texture.getColorFromPosition(position).debug();
        System.out.printf("\tat (%dx, %dy)\n",
                position.x,position.y);
        System.out.printf("\tat (%.1f°, %.1f°)\n",
                coords.x,coords.y);
    }


    public Matrix4f getViewMatrix() {
        // smoothing
        distance += (targetDistance - distance) * 0.1f;
        yaw += (targetYaw - yaw) * 0.1f;
        pitch += (targetPitch - pitch) * 0.1f;

        // Calculate camera orbit position
        float camX = (float) (distance * Math.cos(pitch) * Math.sin(yaw));
        float camY = (float) (distance * Math.sin(pitch));
        float camZ = (float) (distance * Math.cos(pitch) * Math.cos(yaw));

        return new Matrix4f().lookAt(
                new Vector3f(camX, camY, camZ),
                new Vector3f(0, 0, 0),
                new Vector3f(0, 1, 0)
        );

    }


    private Vector3f getCameraDirection() {
        float x = (float) (Math.cos(pitch) * Math.sin(yaw));
        float y = (float) (Math.sin(pitch));
        float z = (float) (Math.cos(pitch) * Math.cos(yaw));
        return new Vector3f(x, y, z);
    }

    public void updateYawPitchFromDirection(Vector3f dir) {
        float newYaw = (float) Math.atan2(dir.x, dir.z);
        float newPitch = (float) Math.asin(dir.y);

        // Unwrap yaw to avoid discontinuities across ±π
        float delta = newYaw - targetYaw;

        // Wrap delta to [-π, π]
        if (delta > Math.PI) delta -= (float) (2 * Math.PI);
        if (delta < -Math.PI) delta += (float) (2 * Math.PI);

        targetYaw += delta;
        targetPitch = newPitch;
    }


    private Vector3f getCameraPosition() {
        float x = (float) (distance * Math.cos(pitch) * Math.sin(yaw));
        float y = (float) (distance * Math.sin(pitch));
        float z = (float) (distance * Math.cos(pitch) * Math.cos(yaw));
        return new Vector3f(x, y, z);
    }

    private Vector3f screenToRay(double mouseX, double mouseY) {
        // Convert screen coords to NDC (-1 to 1)
        float x = (float) (2.0 * mouseX / width - 1.0);
        float y = (float) (1.0 - 2.0 * mouseY / height);

        Vector4f near = new Vector4f(x, y, -1f, 1f);
        Vector4f far  = new Vector4f(x, y,  1f, 1f);

        Matrix4f projection = new Matrix4f();
        float nearZ = 0.01f;
        float farZ = 100f;
        float fovY = (float) Math.toRadians(45.0);
        float aspect = (float) width / height;

        float top = (float) (Math.tan(fovY / 2.0) * nearZ);
        float bottom = -top;
        float right = top * aspect;
        float left = -right;

        projection.frustum(left, right, bottom, top, nearZ, farZ);

        Matrix4f view = getViewMatrix();
        Matrix4f inverse = new Matrix4f(projection).mul(view).invert();

        near.mul(inverse).div(near.w);
        far.mul(inverse).div(far.w);

        Vector3f rayDir = new Vector3f(far.x, far.y, far.z)
                .sub(near.x, near.y, near.z)
                .normalize();

        return rayDir;
    }


    private Vector3f intersectRayWithSphere(Vector3f origin, Vector3f dir, float radius) {
        Vector3f oc = new Vector3f(origin); // camera is at (0, 0, 0)
        float b = 2f * oc.dot(dir);
        float c = oc.dot(oc) - radius * radius;
        float discriminant = b * b - 4f * c;

        if (discriminant < 0) return null; // no hit

        float t = (-b - (float) Math.sqrt(discriminant)) / 2f;
        return new Vector3f(dir).mul(t).add(origin);
    }

    public Vector3f getGrabPoint() {
        return grabPoint == null ? null : new Vector3f(grabPoint);
    }


}
