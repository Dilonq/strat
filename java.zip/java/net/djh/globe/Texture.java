package net.djh.globe;

import org.joml.Vector2d;
import org.joml.Vector2f;
import org.joml.Vector2i;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;

import static org.lwjgl.opengl.GL11C.*;
import static org.lwjgl.stb.STBImage.*;

public class Texture {
    public int id;
    public int width;
    public int height;
    public ByteBuffer buffer;

    public Texture(String path) {
        try (MemoryStack stack = MemoryStack.stackPush()) {

            IntBuffer w = stack.mallocInt(1);
            IntBuffer h = stack.mallocInt(1);
            IntBuffer channels = stack.mallocInt(1);

            stbi_set_flip_vertically_on_load(true);
            ByteBuffer image = stbi_load(path, w, h, channels, 4); // Force RGBA

            if (image == null) {
                throw new RuntimeException("Failed to load image: " + stbi_failure_reason());
            }

            width = w.get(0);
            height = h.get(0);

            int size = width * height * 4;
            buffer = MemoryUtil.memAlloc(size);
            MemoryUtil.memCopy(MemoryUtil.memAddress(image), MemoryUtil.memAddress(buffer), size);
            stbi_image_free(image);


            System.out.println("w");
            // Upload to OpenGL
            id = glGenTextures();
            glBindTexture(GL_TEXTURE_2D, id);
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0,
                    GL_RGBA, GL_UNSIGNED_BYTE, buffer);
            System.out.println("w");
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        }
    }

    public Color getColorFromPosition(Vector2i pos){
        int index = ((pos.y * width + pos.x) * 4);
        return new Color(buffer,index);
    }
}