package net.djh.globe;

import org.joml.Vector2d;
import org.joml.Vector2f;

import java.nio.ByteBuffer;

public class Color {
    public int r,g,b,a = 255;

    public Color(int r,int g, int b, int a){
        this(r,g,b);
        this.a=a;
    }
    public Color(int r,int g, int b){
        this.r=r;
        this.g=g;
        this.b=b;
    }

    public Color(ByteBuffer data, int index){
        this.r = data.get(index) & 0xFF;
        this.g = data.get(index + 1) & 0xFF;
        this.b = data.get(index + 2) & 0xFF;
        this.a = data.get(index + 3) & 0xFF;
    }

    public int grayscale(){
        return (r+g+b)/3;
    }

    public void debug(){
        System.out.print("Color");

        System.out.printf(": #%02X%02X%02X (%d,%d,%d,%d)\n",
                r, g, b, r, g, b, a);
    }
}
